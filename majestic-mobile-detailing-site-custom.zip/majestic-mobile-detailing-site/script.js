// Simple mobile nav toggle and current year
const navToggle = document.querySelector('.nav-toggle');
const siteNav = document.getElementById('site-nav');
if (navToggle && siteNav) {
  navToggle.addEventListener('click', () => {
    const open = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!open));
    siteNav.style.display = open ? 'none' : 'inline-flex';
  });
}
document.getElementById('year').textContent = new Date().getFullYear();
